
import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path

st.set_page_config(
    page_title="Workplace Mental Health Analytics",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded",
)

DATA_FILE = Path(__file__).parent / "mental_health_cleaned.csv"

@st.cache_data
def load_data():
    df = pd.read_csv(DATA_FILE)

    # Keep the cleaned survey structure used by the analysis.
    if "age_group" not in df.columns:
        df["age_group"] = pd.cut(
            df["age"],
            bins=[0, 20, 30, 40, 50, 60, 70],
            labels=["<=20", "21-30", "31-40", "41-50", "51-60", "61-70"],
            include_lowest=True,
        )

    if "mental_health_treatment" not in df.columns:
        df["mental_health_treatment"] = (df["treatment"] == "Yes").astype(int)

    return df

df = load_data()

st.title("🧠 Workplace Mental Health Analytics Dashboard")
st.caption(
    "Interactive Streamlit dashboard based on the charts in the mental_health_analysis notebook. "
    "Treatment-seeking is a survey outcome/proxy, not a clinical diagnosis."
)

# ---------------- Sidebar filters ----------------
st.sidebar.header("Dashboard Filters")

countries = sorted(df["country"].dropna().astype(str).unique())
genders = sorted(df["gender"].dropna().astype(str).unique())
families = sorted(df["family_history"].dropna().astype(str).unique())

selected_countries = st.sidebar.multiselect(
    "Country", countries, help="Leave empty to include all countries."
)
selected_genders = st.sidebar.multiselect(
    "Gender", genders, help="Leave empty to include all genders."
)
selected_family = st.sidebar.multiselect(
    "Family history", families, help="Leave empty to include all responses."
)

d = df.copy()
if selected_countries:
    d = d[d["country"].isin(selected_countries)]
if selected_genders:
    d = d[d["gender"].isin(selected_genders)]
if selected_family:
    d = d[d["family_history"].isin(selected_family)]

# ---------------- KPI row ----------------
total = len(d)
treatment_rate = d["mental_health_treatment"].mean() * 100 if total else 0
family_yes = (d["family_history"].eq("Yes").mean() * 100) if total else 0
physical_yes = (d["phys_health_consequence"].eq("Yes").mean() * 100) if total else 0

k1, k2, k3, k4 = st.columns(4)
k1.metric("Respondents", f"{total:,}")
k2.metric("Treatment-seeking rate", f"{treatment_rate:.1f}%")
k3.metric("Family history: Yes", f"{family_yes:.1f}%")
k4.metric("Physical consequence: Yes", f"{physical_yes:.1f}%")

st.divider()

if d.empty:
    st.warning("No records match the selected filters. Please broaden the filters.")
    st.stop()

# ---------------- Chart 1: Age distribution ----------------
st.subheader("1. Distribution of Respondent Age")
fig1 = px.histogram(
    d, x="age", nbins=20, marginal="box",
    title="Distribution of Respondent Age (Cleaned)",
    labels={"age": "Age", "count": "Number of respondents"},
)
fig1.update_layout(height=450)
st.plotly_chart(fig1, use_container_width=True)

# ---------------- Chart 2: Gender distribution ----------------
st.subheader("2. Respondent Gender Distribution")
gender_counts = d["gender"].value_counts().reset_index()
gender_counts.columns = ["gender", "count"]
fig2 = px.bar(
    gender_counts, x="gender", y="count", text="count",
    title="Respondent Gender Distribution (Standardized)",
    labels={"gender": "Gender", "count": "Count"},
)
fig2.update_traces(textposition="outside")
st.plotly_chart(fig2, use_container_width=True)

# ---------------- Chart 3: Top 10 countries ----------------
st.subheader("3. Top 10 Countries by Number of Respondents")
top_countries = d["country"].value_counts().head(10).sort_values().reset_index()
top_countries.columns = ["country", "count"]
fig3 = px.bar(
    top_countries, x="count", y="country", orientation="h", text="count",
    title="Top 10 Countries by Number of Respondents",
    labels={"country": "Country", "count": "Number of respondents"},
)
fig3.update_traces(textposition="outside")
st.plotly_chart(fig3, use_container_width=True)

# ---------------- Chart 4: Treatment distribution ----------------
st.subheader("4. Mental Health Treatment Distribution")
treatment_counts = d["treatment"].value_counts().reset_index()
treatment_counts.columns = ["treatment", "count"]
fig4 = px.pie(
    treatment_counts, names="treatment", values="count",
    hole=0.42,
    title="Has the Respondent Sought Mental Health Treatment?",
)
fig4.update_traces(textinfo="percent+label")
st.plotly_chart(fig4, use_container_width=True)

# ---------------- Chart 5: Family history distribution ----------------
st.subheader("5. Family History of Mental Illness")
family_counts = (
    d["family_history"]
    .value_counts()
    .reindex(["Yes", "No"])
    .dropna()
    .reset_index()
)
family_counts.columns = ["family_history", "count"]
fig5 = px.bar(
    family_counts, x="family_history", y="count", text="count",
    title="Family History of Mental Illness",
    labels={"family_history": "Family history", "count": "Count"},
)
fig5.update_traces(textposition="outside")
st.plotly_chart(fig5, use_container_width=True)

# ---------------- Chart 8: Age vs Treatment ----------------
st.subheader("6. Age Distribution by Treatment-Seeking Status")
fig6 = px.box(
    d, x="treatment", y="age",
    points="outliers",
    title="Age Distribution by Treatment-Seeking Status",
    labels={"treatment": "Sought treatment", "age": "Age"},
)
st.plotly_chart(fig6, use_container_width=True)

# ---------------- Chart 9: Gender vs Treatment ----------------
st.subheader("7. Treatment-Seeking by Gender")
gender_treatment = (
    d.groupby(["gender", "treatment"])
    .size()
    .reset_index(name="count")
)
fig7 = px.bar(
    gender_treatment, x="gender", y="count", color="treatment",
    barmode="group", text="count",
    title="Treatment-Seeking by Gender",
    labels={"gender": "Gender", "count": "Count", "treatment": "Sought treatment"},
)
fig7.update_traces(textposition="outside")
st.plotly_chart(fig7, use_container_width=True)

# ---------------- Chart 10: Family history vs Treatment ----------------
st.subheader("8. Treatment-Seeking by Family History")
family_treatment = (
    d.groupby(["family_history", "treatment"])
    .size()
    .reset_index(name="count")
)
fig8 = px.bar(
    family_treatment, x="family_history", y="count", color="treatment",
    barmode="group", text="count",
    title="Treatment-Seeking by Family History of Mental Illness",
    labels={
        "family_history": "Family history",
        "count": "Count",
        "treatment": "Sought treatment",
    },
)
fig8.update_traces(textposition="outside")
st.plotly_chart(fig8, use_container_width=True)

# ---------------- Chart 17: Country treatment rate ----------------
st.subheader("9. Treatment-Seeking Rate by Country")
top10 = d["country"].value_counts().head(10).index
country_df = d[d["country"].isin(top10)].copy()
country_rate = (
    country_df.groupby("country")["mental_health_treatment"]
    .mean()
    .mul(100)
    .sort_values()
    .reset_index()
)
country_rate.columns = ["country", "treatment_rate"]
fig9 = px.bar(
    country_rate, x="treatment_rate", y="country", orientation="h",
    text=country_rate["treatment_rate"].map(lambda x: f"{x:.1f}%"),
    title="Treatment-Seeking Rate by Country (Top 10 by Respondent Count)",
    labels={"country": "Country", "treatment_rate": "Treatment-seeking rate (%)"},
)
fig9.update_xaxes(range=[0, 100])
fig9.update_traces(textposition="outside")
st.plotly_chart(fig9, use_container_width=True)

# ---------------- Data preview / download ----------------
with st.expander("View filtered data"):
    st.dataframe(d, use_container_width=True, height=400)

st.download_button(
    "⬇️ Download filtered CSV",
    d.to_csv(index=False).encode("utf-8"),
    file_name="mental_health_filtered.csv",
    mime="text/csv",
)

st.divider()
st.caption(
    "Source analysis: OSMI Mental Health in Tech Survey (2014) as processed in the supplied notebook. "
    "Charts are interactive versions of the notebook's visualizations."
)
