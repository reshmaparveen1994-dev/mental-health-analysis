# Workplace Mental Health Streamlit Dashboard

This dashboard converts the visualizations from `mental_health_analysis(1).ipynb` into an interactive Streamlit app.

## Included notebook charts
1. Age distribution
2. Gender distribution
3. Top 10 countries
4. Treatment distribution
5. Family history distribution
6. Age vs treatment
7. Gender vs treatment
8. Family history vs treatment
9. Country treatment rate

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

The app expects `mental_health_cleaned.csv` in the same folder.
